# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\DACODADOBOBACACABABODODOCABOCODACOB.txt")
# s = f.read()

# soglas = "BCD"
# glas = "AO"
# cnt = 0
# cntmax = 0
# for i in range(1, len(s) - 1, 2):
#     if s[i-1] in soglas and s[i] in glas:
#         cnt += 1
#         cntmax = max(cnt, cntmax)
#     if s[i] in soglas and s[i+1] in glas:
#         cnt += 1
#         cntmax = max(cnt, cntmax)
#     else:
#         cnt = 0
# print(cntmax)


# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\DACODADOBOBACACABABODODOCABOCODACOB (2).txt")
# s = f.read()

# h = s.replace("BAC", "1") # потом поменять реплейсы местами
# h = h.replace("CAB", "1")
# cnt = 0
# cntmax = 0
# for i in range(len(h)):
#     if h[i] == "1":
#         cnt += 3
#         cntmax = max(cnt, cntmax)
#     else:
#         cnt = 0
# print(cntmax)


f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\DACODADOBOBACACABABODODOCABOCODACOB (3).txt")
s = f.read()

cnt = 0
cntmax = 0
for i in range(len(s)):
    if s[i:i+3] == "XYZ":
        cnt += 3
        cntmax = max(cnt, cntmax)
    if cnt >= 3:
        if s[i] == "X":
            cnt += 1
            cntmax = max(cnt, cntmax)
        elif s[i:i+2] == "XY":
            cnt += 2
            cntmax = max(cnt, cntmax)
        else:
            cnt = 0
print(cntmax)