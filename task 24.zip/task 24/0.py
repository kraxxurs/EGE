f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\1.txt")
s = f.read()

a = 0
a_max = 0
for i in range(len(s)):
    if s[i] == "A" and (s[i+1] == "B" or s[i+1] == "C"):
        a += 1
        for j in range(i+2, len(s), 2):
            if s[i] == "A" and (s[i+1] == "B" or s[i+1] == "C"):
                a += 1
        a_max = max(a, a_max)
    else:
        a = 0
print(a_max)


# s = s.replace("AB", "1")
# s = s.replace("AC", "1")
# a = 0
# a_max = 0
# for i in range(len(s)):
#     if s[i] == "1":
#         a += 1
#         a_max = max(a, a_max)
#     else:
#         a = 0
# print(a_max)


f = open("24-384.txt")
s = f.read().strip()

# запоминаем позиции всех вхождений Z
positions = [i for i, c in enumerate(s) if c == 'Z']

K = 270
best = float("inf")
for i in range(len(positions) - K + 1):
    # окно от i-го вхождения Z до (i+K-1)-го вхождения Z
    length = positions[i + K - 1] - positions[i] + 1
    if length < best:
        best = length

print(best)