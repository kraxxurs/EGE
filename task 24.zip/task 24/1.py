# 9005

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-385.txt")
# s = f.read()

# alf = "0123456789AB"
# cnt = 0
# cnt_max = 0
# for i in range(len(s)):
#     if s[i] in alf:
#         cnt += 1
#         cnt_max = max(cnt, cnt_max)
#     else:
#         cnt = 0
# print(cnt_max)


# 9004 !!! 

f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-384.txt")
s = f.read()

minn = float("inf")
for i in range(len(s)):
    count = 0
    abs_count = 0
    for j in range(i, len(s)):
        if s[j] == "Z":
            count += 1
        else:
            abs_count += 1
        if count > 269:
            length = count + abs_count
            minn = min(minn, length)
            break
print(minn)


# 8948

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-378 (1).txt")
# s = f.read()

# nums = "0123456789"
# lets = "ABCDEF"
# cnt_min = float("inf")
# for i in range(len(s)):
#     n_list = []
#     l_list = []
#     for j in range(i, len(s)):
#         if s[j] in nums:
#             n_list.append(s[j])
#         if s[j] in lets:
#             l_list.append(s[j])
#             if len(l_list) > 3:
#                 break
#         if len(set(n_list)) == 10 and len(l_list) == 3:
#             cnt_min = min(j - i + 1, cnt_min)
#             break
# print(cnt_min)


# 8947 !!!

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-378 (1).txt")
# s = f.read()

# nums = "0123456789"
# lets = "PQRSTUVWXYZ"
# cnt_max = 0
# for i in range(len(s)):
#     n_list = []
#     l_list = []
#     for j in range(i, len(s)):
#         if s[j] in nums:
#             n_list.append(s[j])
#         if s[j] in lets:
#             l_list.append(s[j])
#             if len(l_list) > 3:
#                 break
#         if len(set(n_list)) == 10 and len(l_list) == 3:
#             cnt_max = max(j - i + 1, cnt_max)
#             break
# print(cnt_max)


# 8946

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-378 (1).txt")
# s = f.read()

# nums = "0123456789"
# lets = "ABCDEF"
# cnt_min = float("inf")
# for i in range(len(s)):
#     n_list = []
#     for j in range(i, len(s)):
#         if s[j] in nums:
#             n_list.append(s[j])
#         if s[j] in lets:
#             break
#         if len(set(n_list)) == 10:
#             cnt_min = min(cnt_min, j - i + 1)
#             break
# print(cnt_min)


# 8945

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-378 (1).txt")
# s = f.read()

# nums = "01234567890"
# lets = "KLMNOPQRSTUVWXYZ"
# cnt_max = 0
# for i in range(len(s)):
#     n_list = []
#     for j in range(i, len(s)):
#         if s[j] in nums:
#             n_list.append(s[j])
#         if s[j] in lets:
#             break
#         if len(set(nums)) == 10:
#             cnt_max = max(cnt_max, j - i + 1)
# print(cnt_max)


# 8944
# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-378 (1).txt")
# s = f.read()

# nums = "01234567890"
# lets = "PQRSTUVWXYZ"
# cnt_min = float("inf")
# for i in range(len(s)):
#     l_list = []
#     for j in range(i, len(s)):
#         if s[j] in lets:
#             l_list.append(s[j])
#         if s[j] in nums:
#             break
#         if len(set(l_list)) == len(lets):
#             cnt_min = min(cnt_min, j - i + 1)
# print(cnt_min)


# 8840 !!!
# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-371.txt")
# s = f.read()


# 8230 !!!

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-359.txt")
# s = f.read()

# cntmin = float("inf")
# for i in range(len(s)):
#     kn = 0
#     ke = 0
#     for j in range(i, len(s)):
#         if j >= i and s[j-3:j+1] == "2025":
#             kn += 1
#         if s[j] == "E":
#             ke += 1
#             if ke > 110:
#                 break
#         if kn >= 90 and ke == 110:
#             cntmin = min(cntmin, j - i + 1)
#             break
# print(cntmin)


# 8134 !!!

# f = open(r"D:\Кира\ИНТ\11\икт\EGE\task 24\24-357.txt")
# s = f.read().strip()

# cntmin = float("inf")
# for i in range(len(s)):
#     k = 0
#     for j in range(i, len(s)):
#         if j >= i + 2 and s[j-2:j+1] == "RSQ":
#             k += 1
#             if k > 130:
#                 break
#         if k == 130 and s[j] != "Q":
#             cnt = j - i + 1
#             if cnt < cntmin:
#                 cntmin = cnt
#             break
# print(cntmin)
